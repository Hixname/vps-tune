# 发布到 GitHub

## 1. 创建空仓库

在 GitHub 新建一个公开仓库，建议命名：

```text
mmwx-vps-tune
```

创建时不要自动添加 README、`.gitignore` 或 License，因为这些文件已经包含在发布包中。

## 2. 推送文件

解压发布包并进入项目目录：

```bash
unzip mmwx-vps-tune-github.zip
cd mmwx-vps-tune-github
```

初始化并提交：

```bash
git init
git add .
git commit -m "feat: add mmwx VPS tuning wrapper"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/mmwx-vps-tune.git
git push -u origin main
```

把 `YOUR_GITHUB_USERNAME` 替换为你的 GitHub 用户名。不要把 SSH 私钥、妙妙屋X token、Agent 配置或 Xray 私钥复制进仓库。

## 3. 检查 GitHub Actions

进入仓库的 **Actions** 页面，确认 `static-check` 工作流通过。工作流会执行：

- Bash 语法检查；
- ShellCheck；
- 安装器内置主脚本哈希检查；
- `SHA256SUMS` 检查。

## 4. 在 VPS 上使用

root shell：

```bash
curl -fsSL \
  https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/mmwx-vps-tune/main/install.sh |
  MMWX_TUNE_REPO=YOUR_GITHUB_USERNAME/mmwx-vps-tune bash -s -- apply
```

更稳妥的审查式安装方法见 [`README.md`](README.md)。

## 5. 创建首个 Release

确认 Actions 通过并完成目标 VPS 验证后再创建版本标签：

```bash
git tag -a v1.1.0 -m "mmwx-vps-tune v1.1.0"
git push origin v1.1.0
```

随后在 GitHub 的 **Releases → Draft a new release** 中选择 `v1.1.0`，附上 ZIP 和 `SHA256SUMS`。正式发布前请至少验证：

1. `preflight`；
2. `apply`；
3. 立即 `verify`；
4. 重启后 `verify`；
5. `rollback`；
6. 原有妙妙屋X节点连通性。
